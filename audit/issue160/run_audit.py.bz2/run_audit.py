from __future__ import annotations

import argparse
import copy
import hashlib
import json
import statistics
import tempfile
from dataclasses import asdict
from pathlib import Path
from typing import Any, Callable

from gates_of_codex.actor_economy import (
    ACTOR_CONTENT_KEY,
    actor_content_snapshot,
    actor_recruitment_offers,
    assign_actor_reinforcements,
    available_actor_research,
    install_actor_content,
    purchase_actor_reinforcements,
    purchase_actor_research,
    repair_actor_formation,
    settle_actor_round_economy,
    validate_actor_content_runtime,
)
from gates_of_codex.force_migration import ensure_strategic_formations
from gates_of_codex.models import Faction
from gates_of_codex.scenario import load_bundled_scenario
from gates_of_codex.state_io import load_campaign, save_campaign
from gates_of_codex.strategic_actors import (
    ACTOR_RUNTIME_KEY,
    assign_province_actor,
    assign_strategic_formation_actor,
    ensure_strategic_actor_runtime,
    install_bundled_strategic_actors,
    selected_actor,
    set_selected_actor,
    strategic_actor_snapshot,
    validate_strategic_actor_runtime,
)

AUDITED_COMMIT = "14d784de63d58ddbf993d71f95d9f31b8a370cb2"
ACCEPTED_PAYLOAD_SHA256 = "d2565337aac74659308c5fc1ca1ff2fe543c7117fb940a196867a33d7d569b46"
ACCEPTED_WIRING_SIGNATURE = "6021157beba4b82afc2ac645477b3c02ea7178a88e8ddbb13bfef05a55ad4581"
EXPECTED_HOSTS = {
    "ukr_ildu": "ukr",
    "kpa_expeditionary": "rus",
    "wagner": "rus",
}
RUSA_ISOLATION_ACTORS = ("blr", "donbas", "srb", "rus", "dprk", "wagner")


class AuditFailure(AssertionError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AuditFailure(message)


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def canonical_stats(values: list[int]) -> dict[str, int | float]:
    if not values:
        return {"minimum": 0, "median": 0, "maximum": 0, "total": 0}
    median = statistics.median(values)
    return {
        "minimum": min(values),
        "median": int(median) if float(median).is_integer() else float(median),
        "maximum": max(values),
        "total": sum(values),
    }


def load_payload(path: Path) -> dict[str, Any]:
    raw = path.read_bytes()
    digest = sha256_bytes(raw)
    require(digest == ACCEPTED_PAYLOAD_SHA256, f"accepted payload hash mismatch: {digest}")
    payload = json.loads(raw.decode("utf-8-sig"))
    require(payload["actor_count"] == 24, "accepted payload actor count is not 24")
    require(payload["error_count"] == 0, "accepted payload contains errors")
    require(payload["warning_count"] == 0, "accepted payload contains warnings")
    require(payload["wiring_signature"] == ACCEPTED_WIRING_SIGNATURE, "wiring signature mismatch")
    return payload


def fresh_state() -> Any:
    state = load_bundled_scenario()
    ensure_strategic_formations(state)
    return state


def installed_state(payload: dict[str, Any], selected: str = "fra") -> Any:
    state = fresh_state()
    install_actor_content(state, payload, selected_actor_id=selected)
    validate_actor_content_runtime(state)
    validate_strategic_actor_runtime(state)
    return state


def force_for_side(state: Any, faction: Faction, *, single: bool = True) -> Any:
    candidates = [
        force
        for force in state.strategic_formations.values()
        if force.faction == faction
        and (not single or len([bid for bid in force.battalion_ids if bid in state.battalions]) == 1)
    ]
    require(bool(candidates), f"no suitable strategic formation for {faction.value}")
    return sorted(candidates, key=lambda force: force.strategic_formation_id)[0]


def actor_rows(state: Any) -> dict[str, dict[str, Any]]:
    runtime = state.map_metadata[ACTOR_RUNTIME_KEY]
    return runtime["actors"]


def set_actor_resources(state: Any, actor_id: str, value: int) -> None:
    actor_rows(state)[actor_id]["resources"] = value
    validate_strategic_actor_runtime(state)


def grant_all_research(state: Any, actor_id: str) -> None:
    nodes = state.map_metadata[ACTOR_CONTENT_KEY]["actors"][actor_id]["research_nodes"]
    actor_rows(state)[actor_id]["researched_keys"] = sorted(nodes)
    validate_strategic_actor_runtime(state)
    validate_actor_content_runtime(state)


def save_bytes(state: Any) -> bytes:
    with tempfile.TemporaryDirectory() as directory:
        path = Path(directory) / "campaign.json"
        save_campaign(state, path)
        return path.read_bytes()


def reload_state(state: Any) -> Any:
    with tempfile.TemporaryDirectory() as directory:
        path = Path(directory) / "campaign.json"
        save_campaign(state, path)
        return load_campaign(path)


def offers_for_actor(state: Any, force: Any, actor_id: str) -> set[str]:
    assign_strategic_formation_actor(state, force.strategic_formation_id, actor_id)
    return {offer.unit_name for offer in actor_recruitment_offers(state, force.strategic_formation_id)}


def first_offer(state: Any, force: Any, actor_id: str) -> Any:
    assign_strategic_formation_actor(state, force.strategic_formation_id, actor_id)
    grant_all_research(state, actor_id)
    offers = [offer for offer in actor_recruitment_offers(state, force.strategic_formation_id) if offer.unlocked]
    require(bool(offers), f"actor {actor_id} has no unlocked recruitment offer")
    return sorted(offers, key=lambda offer: (offer.purchase_cost, offer.unit_name))[0]


def deterministic_pair(
    payload: dict[str, Any],
    operation: str,
    runner: Callable[[dict[str, Any]], Any],
) -> dict[str, Any]:
    state_a = runner(payload)
    state_b = runner(payload)
    bytes_a = save_bytes(state_a)
    bytes_b = save_bytes(state_b)
    hash_a = sha256_bytes(bytes_a)
    hash_b = sha256_bytes(bytes_b)
    require(bytes_a == bytes_b, f"nondeterministic output for {operation}: {hash_a} != {hash_b}")
    return {"operation": operation, "sha256": hash_a, "byte_count": len(bytes_a), "identical": True}


def run_phase5(payload: dict[str, Any]) -> dict[str, Any]:
    legacy = fresh_state()
    require(ACTOR_CONTENT_KEY not in legacy.map_metadata, "actor content was installed before explicit activation")
    legacy_roundtrip = reload_state(legacy)
    require(ACTOR_CONTENT_KEY not in legacy_roundtrip.map_metadata, "ordinary save/load installed actor content")

    state = fresh_state()
    actors = install_bundled_strategic_actors(state, selected_actor_id="fra")
    require(len(actors) == 24, "bundled strategic actor install did not produce 24 actors")
    require(selected_actor(state).actor_id == "fra", "France was not retained as selected strategic actor")
    require(state.selected_faction == Faction.NATO, "France did not map to NATO tactical side")

    for actor_id, host_id in EXPECTED_HOSTS.items():
        require(actors[actor_id].host_actor_id == host_id, f"host mismatch for {actor_id}")
        require(not actors[actor_id].playable, f"hosted actor {actor_id} is independently playable")
        require(actors[actor_id].coalition_id == actors[host_id].coalition_id, f"host coalition mismatch for {actor_id}")
        try:
            set_selected_actor(state, actor_id)
        except ValueError:
            pass
        else:
            raise AuditFailure(f"hosted actor {actor_id} was selectable")

    set_selected_actor(state, "dprk")
    require(selected_actor(state).actor_id == "dprk", "DPRK selection did not persist in memory")
    require(state.selected_faction == Faction.RUSSIA, "DPRK did not map to RUSA tactical side")
    loaded = reload_state(state)
    require(selected_actor(loaded).actor_id == "dprk", "DPRK selection did not survive save/load")
    require(loaded.selected_faction == Faction.RUSSIA, "DPRK tactical side changed after save/load")

    nato_force = force_for_side(loaded, Faction.NATO)
    try:
        assign_strategic_formation_actor(loaded, nato_force.strategic_formation_id, "dprk")
    except ValueError:
        pass
    else:
        raise AuditFailure("formation actor/tactical-side mismatch was accepted")

    nato_province = next(province for province in loaded.provinces.values() if province.owner == Faction.NATO)
    try:
        assign_province_actor(loaded, nato_province.province_id, "dprk")
    except ValueError:
        pass
    else:
        raise AuditFailure("province actor/tactical-side mismatch was accepted")

    validate_strategic_actor_runtime(loaded)
    return {
        "actor_count": len(actors),
        "france_tactical_side": "nato",
        "dprk_tactical_side": "rusa",
        "selection_round_trip": True,
        "host_relationships": EXPECTED_HOSTS,
        "hosted_selection_rejected": True,
        "legacy_content_install_is_explicit": True,
        "tactical_side_mismatch_rejected": True,
        "snapshot_sha256": sha256_bytes(json.dumps(strategic_actor_snapshot(loaded), sort_keys=True).encode()),
    }


def run_phase6(payload: dict[str, Any]) -> dict[str, Any]:
    state = installed_state(payload, "fra")
    runtime = state.map_metadata[ACTOR_CONTENT_KEY]
    require(runtime["actor_count"] == 24, "actor content runtime does not contain 24 actors")

    nato_force = force_for_side(state, Faction.NATO)
    rusa_force = force_for_side(state, Faction.RUSSIA)
    france_offers = offers_for_actor(state, nato_force, "fra")
    germany_offers = offers_for_actor(state, nato_force, "deu")
    france_unique = sorted(france_offers - germany_offers)
    germany_unique = sorted(germany_offers - france_offers)
    require(bool(france_unique), "France has no roster identity distinct from Germany")
    require(bool(germany_unique), "Germany has no roster identity distinct from France")
    require(france_unique[0] not in germany_offers, "Germany can recruit a France-only unit")
    require(germany_unique[0] not in france_offers, "France can recruit a Germany-only unit")

    dprk_offers = offers_for_actor(state, rusa_force, "dprk")
    russia_offers = offers_for_actor(state, rusa_force, "rus")
    dprk_unique = sorted(dprk_offers - russia_offers)
    russia_unique = sorted(russia_offers - dprk_offers)
    require(bool(dprk_unique), "DPRK has no roster identity distinct from Russia")
    require(bool(russia_unique), "Russia has no roster identity distinct from DPRK")
    require(russia_unique[0] not in dprk_offers, "DPRK can recruit a Russia-only unit")

    ukraine = runtime["actors"]["ukr"]["units"]
    hosted_ildu = runtime["actors"]["ukr_ildu"]["units"]
    ukr_ildu_names = sorted(name for name, unit in ukraine.items() if unit["component_id"] == "ukraine_ildu")
    require(len(ukr_ildu_names) == 6, "Ukraine ILDU branch does not contain exactly six wrappers")
    require(set(ukr_ildu_names) == set(hosted_ildu), "hosted ILDU roster differs from Ukraine explicit ILDU component")
    require(all(name.startswith("goc_ildu_") for name in ukr_ildu_names), "non-ILDU unit entered the ILDU component")
    for actor_id, content in runtime["actors"].items():
        if actor_id not in {"ukr", "ukr_ildu"}:
            require(not any(name.startswith("goc_ildu_") for name in content["units"]), f"ILDU wrapper leaked into {actor_id}")

    for actor_id, content in runtime["actors"].items():
        prefix = f"actor:{actor_id}:"
        for key, node in content["research_nodes"].items():
            require(key.startswith(prefix), f"cross-actor research key in {actor_id}: {key}")
            require(node["actor_id"] == actor_id, f"research actor mismatch: {key}")
        for unit in content["units"].values():
            require(all(key.startswith(prefix) for key in unit["research_options"]), f"unit has cross-actor research option: {actor_id}:{unit['unit_name']}")

    bad_payload = copy.deepcopy(payload)
    france = next(actor for actor in bad_payload["actors"] if actor["actor_id"] == "fra")
    mutable_node = next(node for node in france["research_nodes"] if node["node_type"] != "root")
    mutable_node["key"] = "actor:deu:forged-cross-actor-key"
    try:
        install_actor_content(fresh_state(), bad_payload, selected_actor_id="fra")
    except ValueError:
        pass
    else:
        raise AuditFailure("cross-actor research payload was accepted")

    migration_exceptions = runtime["migration_exceptions"]
    require(bool(migration_exceptions), "no grandfathered migration exceptions were recorded")
    exception_counts: dict[str, int] = {}
    for item in migration_exceptions:
        actor_id = item["actor_id"]
        exception_counts[actor_id] = exception_counts.get(actor_id, 0) + 1
        require(item["unit_name"] not in runtime["actors"][actor_id]["units"], "grandfathered unit is recruitable in actor roster")
        require("grandfathered" in item["reason"], "migration exception is not labeled grandfathered")

    for index, actor_id in enumerate(RUSA_ISOLATION_ACTORS):
        set_actor_resources(state, actor_id, 1_000_000 + index * 10_000)
    resources_before = {actor_id: actor_rows(state)[actor_id]["resources"] for actor_id in RUSA_ISOLATION_ACTORS}
    pool_records = []
    for actor_id in RUSA_ISOLATION_ACTORS:
        offer = first_offer(state, rusa_force, actor_id)
        before_step = {key: actor_rows(state)[key]["resources"] for key in RUSA_ISOLATION_ACTORS}
        purchase = purchase_actor_reinforcements(state, rusa_force.strategic_formation_id, offer.unit_name, 1)
        after_step = {key: actor_rows(state)[key]["resources"] for key in RUSA_ISOLATION_ACTORS}
        require(after_step[actor_id] == before_step[actor_id] - purchase.total_cost, f"treasury debit mismatch for {actor_id}")
        for other in RUSA_ISOLATION_ACTORS:
            if other != actor_id:
                require(after_step[other] == before_step[other], f"treasury leak from {actor_id} to {other}")
        pool_records.append(asdict(purchase))

    pool = runtime["reinforcement_pool"]
    pool_keys = [(entry["actor_id"], entry["strategic_formation_id"], entry["unit_name"]) for entry in pool]
    require(len(pool_keys) == len(set(pool_keys)), "reinforcement pool contains duplicate compound keys")
    require(set(entry["actor_id"] for entry in pool) >= set(RUSA_ISOLATION_ACTORS), "not every isolation actor retained a separate pool entry")

    operation_state = installed_state(payload, "fra")
    operation_force = force_for_side(operation_state, Faction.NATO)
    assign_strategic_formation_actor(operation_state, operation_force.strategic_formation_id, "fra")
    set_actor_resources(operation_state, "fra", 5_000_000)
    available = available_actor_research(operation_state, "fra")
    require(bool(available), "France has no available research after installation")
    research_purchase = purchase_actor_research(operation_state, "fra", sorted(available, key=lambda item: (item.cost, item.key))[0].key)
    grant_all_research(operation_state, "fra")
    offer = first_offer(operation_state, operation_force, "fra")
    reinforcement_purchase = purchase_actor_reinforcements(operation_state, operation_force.strategic_formation_id, offer.unit_name, 2)
    battalion_id = sorted(bid for bid in operation_force.battalion_ids if bid in operation_state.battalions)[0]
    reinforcement_transfer = assign_actor_reinforcements(
        operation_state,
        operation_force.strategic_formation_id,
        offer.unit_name,
        1,
        battalion_id=battalion_id,
    )
    battalion = operation_state.battalions[battalion_id]
    battalion.condition = 80
    battalion.supply = 100
    battalion.encircled_turns = 0
    repair = repair_actor_formation(
        operation_state,
        operation_force.strategic_formation_id,
        5,
        battalion_id=battalion_id,
    )

    province = next(value for value in operation_state.provinces.values() if value.owner == Faction.NATO)
    assign_province_actor(operation_state, province.province_id, "fra")
    reports = {report.actor_id: report for report in settle_actor_round_economy(operation_state)}
    require(reports["fra"].income >= province.resource_yield, "France did not receive explicitly owned province income")
    require(reports["deu"].income == 0, "Germany received France-owned province income")

    snapshot_before = actor_content_snapshot(operation_state)
    snapshot_after = actor_content_snapshot(reload_state(operation_state))
    require(snapshot_after == snapshot_before, "actor content did not survive save/load")

    resources_after = {actor_id: actor_rows(state)[actor_id]["resources"] for actor_id in RUSA_ISOLATION_ACTORS}
    return {
        "france_only_example": france_unique[0],
        "germany_only_example": germany_unique[0],
        "dprk_only_example": dprk_unique[0],
        "russia_only_example": russia_unique[0],
        "ukraine_ildu_units": ukr_ildu_names,
        "cross_actor_research_rejected": True,
        "migration_exception_count": len(migration_exceptions),
        "migration_exception_counts": dict(sorted(exception_counts.items())),
        "rusa_isolation_actors": list(RUSA_ISOLATION_ACTORS),
        "treasuries_before": resources_before,
        "treasuries_after": resources_after,
        "pool_keys": [list(key) for key in sorted(pool_keys)],
        "pool_isolation": True,
        "research_purchase": asdict(research_purchase),
        "reinforcement_purchase": asdict(reinforcement_purchase),
        "reinforcement_transfer": asdict(reinforcement_transfer),
        "repair": asdict(repair),
        "france_income": reports["fra"].income,
        "germany_income": reports["deu"].income,
        "save_load_preserved": True,
    }


def run_phase7(payload: dict[str, Any]) -> dict[str, Any]:
    state = installed_state(payload, "fra")
    runtime = state.map_metadata[ACTOR_CONTENT_KEY]
    per_actor: dict[str, Any] = {}
    total_units = 0
    total_nodes = 0

    exception_counts: dict[str, int] = {}
    for item in runtime["migration_exceptions"]:
        exception_counts[item["actor_id"]] = exception_counts.get(item["actor_id"], 0) + 1

    for actor_id in sorted(runtime["actors"]):
        content = runtime["actors"][actor_id]
        units = content["units"]
        nodes = content["research_nodes"]
        total_units += len(units)
        total_nodes += len(nodes)
        prefix = f"actor:{actor_id}:"
        visiting: set[str] = set()
        visited: set[str] = set()

        def visit(key: str) -> None:
            if key in visited:
                return
            require(key not in visiting, f"research cycle detected for {actor_id}: {key}")
            visiting.add(key)
            for prerequisite in nodes[key]["prerequisites"]:
                require(prerequisite in nodes, f"missing prerequisite for {key}: {prerequisite}")
                visit(prerequisite)
            visiting.remove(key)
            visited.add(key)

        for key, node in nodes.items():
            require(key.startswith(prefix), f"unscoped research key for {actor_id}: {key}")
            expected_cost = 0 if node["node_type"] == "root" else max(50, node["source_cost"] * 50)
            require(node["cost"] == expected_cost, f"strategic research cost conversion mismatch for {key}")
            if node["node_type"] != "root":
                require(node["cost"] > 0, f"zero-cost non-root research for {key}")
            for unit_name in node["unlock_units"]:
                require(unit_name in units, f"research {key} unlocks missing unit {unit_name}")
            visit(key)

        roots = {key for key, node in nodes.items() if node["node_type"] == "root"}
        require(bool(roots), f"actor {actor_id} has no research root")
        for key in nodes:
            closure: set[str] = set()
            stack = [key]
            while stack:
                current = stack.pop()
                if current in closure:
                    continue
                closure.add(current)
                stack.extend(nodes[current]["prerequisites"])
            require(bool(closure & roots), f"research node is not root-reachable: {key}")

        purchase_values = [unit["purchase_cost"] for unit in units.values()]
        research_values = [node["cost"] for node in nodes.values() if node["node_type"] != "root"]
        per_actor[actor_id] = {
            "unit_count": len(units),
            "research_node_count": len(nodes),
            "root_count": len(roots),
            "purchase_costs": canonical_stats(purchase_values),
            "research_costs": canonical_stats(research_values),
            "migration_exception_count": exception_counts.get(actor_id, 0),
        }

    require(total_units == 1120, f"unexpected actor-unit count: {total_units}")
    require(total_nodes == 1418, f"unexpected research-node count: {total_nodes}")
    return {
        "actor_count": len(per_actor),
        "unit_count": total_units,
        "research_node_count": total_nodes,
        "all_keys_actor_scoped": True,
        "all_prerequisites_exist": True,
        "acyclic": True,
        "all_unlocks_exist": True,
        "all_nodes_root_reachable": True,
        "no_zero_cost_non_root": True,
        "cost_conversion_exact": True,
        "compiler_filtered_branch_and_source_order_tests": "passed in accepted 691-test repository suite",
        "per_actor": per_actor,
    }


def run_phase8(payload: dict[str, Any]) -> dict[str, Any]:
    def actor_install(_: dict[str, Any]) -> Any:
        state = fresh_state()
        install_bundled_strategic_actors(state, selected_actor_id="fra")
        return state

    def actor_select(_: dict[str, Any]) -> Any:
        state = fresh_state()
        install_bundled_strategic_actors(state, selected_actor_id="fra")
        set_selected_actor(state, "dprk")
        return state

    def content_install(p: dict[str, Any]) -> Any:
        return installed_state(p, "fra")

    def research_buy(p: dict[str, Any]) -> Any:
        state = installed_state(p, "fra")
        set_actor_resources(state, "fra", 5_000_000)
        research = sorted(available_actor_research(state, "fra"), key=lambda item: (item.cost, item.key))[0]
        purchase_actor_research(state, "fra", research.key)
        return state

    def reinforce_buy(p: dict[str, Any]) -> Any:
        state = installed_state(p, "fra")
        force = force_for_side(state, Faction.NATO)
        set_actor_resources(state, "fra", 5_000_000)
        offer = first_offer(state, force, "fra")
        purchase_actor_reinforcements(state, force.strategic_formation_id, offer.unit_name, 1)
        return state

    def reinforce_assign(p: dict[str, Any]) -> Any:
        state = installed_state(p, "fra")
        force = force_for_side(state, Faction.NATO)
        set_actor_resources(state, "fra", 5_000_000)
        offer = first_offer(state, force, "fra")
        purchase_actor_reinforcements(state, force.strategic_formation_id, offer.unit_name, 1)
        battalion_id = sorted(bid for bid in force.battalion_ids if bid in state.battalions)[0]
        assign_actor_reinforcements(state, force.strategic_formation_id, offer.unit_name, 1, battalion_id=battalion_id)
        return state

    def repair(p: dict[str, Any]) -> Any:
        state = installed_state(p, "fra")
        force = force_for_side(state, Faction.NATO)
        assign_strategic_formation_actor(state, force.strategic_formation_id, "fra")
        set_actor_resources(state, "fra", 5_000_000)
        battalion_id = sorted(bid for bid in force.battalion_ids if bid in state.battalions)[0]
        battalion = state.battalions[battalion_id]
        battalion.condition = 80
        battalion.supply = 100
        battalion.encircled_turns = 0
        repair_actor_formation(state, force.strategic_formation_id, 5, battalion_id=battalion_id)
        return state

    def settle(p: dict[str, Any]) -> Any:
        state = installed_state(p, "fra")
        province = next(value for value in state.provinces.values() if value.owner == Faction.NATO)
        assign_province_actor(state, province.province_id, "fra")
        settle_actor_round_economy(state)
        return state

    operations = [
        ("actor_installation", actor_install),
        ("actor_selection", actor_select),
        ("actor_content_installation", content_install),
        ("research_purchase", research_buy),
        ("reinforcement_purchase", reinforce_buy),
        ("reinforcement_assignment", reinforce_assign),
        ("repair", repair),
        ("round_settlement", settle),
    ]
    results = [deterministic_pair(payload, name, runner) for name, runner in operations]

    state = installed_state(payload, "fra")
    first = save_bytes(state)
    loaded = reload_state(state)
    second = save_bytes(loaded)
    require(first == second, "save/load round trip changed canonical campaign bytes")
    results.append({
        "operation": "save_load_round_trip",
        "sha256": sha256_bytes(first),
        "byte_count": len(first),
        "identical": True,
    })
    return {"all_identical": True, "operations": results}


def markdown_report(result: dict[str, Any]) -> str:
    phase7 = result["phase7"]
    lines = [
        "# Independent actor runtime and economy audit, phases 5-8",
        "",
        f"Audited commit: `{result['audited_commit']}`",
        f"Accepted payload SHA-256: `{result['accepted_payload_sha256']}`",
        f"Wiring signature: `{result['wiring_signature']}`",
        "",
        "## Verdict",
        "",
        "APPROVE for phases 5-8.",
        "",
        "All strategic actor, actor-content, economy, research, isolation, and deterministic round-trip gates passed.",
        "Native Gates of Hell wrapper spawning remains outside this audit and is tracked by issue #161.",
        "",
        "## Phase 5",
        "",
        f"- Actor count: {result['phase5']['actor_count']}",
        "- France persisted as `fra -> nato`.",
        "- DPRK persisted as `dprk -> rusa` across save/load.",
        "- Hosted actors were rejected as independent selections.",
        "- Formation and province tactical-side mismatches were rejected.",
        "- National actor content remained explicitly installed only.",
        "",
        "## Phase 6",
        "",
        f"- Migration exceptions: {result['phase6']['migration_exception_count']}",
        "- France/Germany and DPRK/Russia roster boundaries passed.",
        "- Belarus, Donbas, Serbia, Russia, DPRK, and Wagner treasury and reinforcement-pool isolation passed.",
        "- Ukraine ILDU content remained in the explicit `ukraine_ildu` component.",
        "- Research, purchase, assignment, repair, settlement, and save/load passed.",
        "",
        "## Phase 7",
        "",
        f"- Units: {phase7['unit_count']}",
        f"- Research nodes: {phase7['research_node_count']}",
        "- All keys actor-scoped, all prerequisites present, no cycles, all unlocks valid.",
        "- No zero-cost non-root research and exact strategic cost conversion.",
        "",
        "| Actor | Units | Nodes | Purchase min/median/max/total | Research min/median/max/total | Migration exceptions |",
        "|---|---:|---:|---|---|---:|",
    ]
    for actor_id, stats in phase7["per_actor"].items():
        p = stats["purchase_costs"]
        r = stats["research_costs"]
        lines.append(
            f"| {actor_id} | {stats['unit_count']} | {stats['research_node_count']} | "
            f"{p['minimum']}/{p['median']}/{p['maximum']}/{p['total']} | "
            f"{r['minimum']}/{r['median']}/{r['maximum']}/{r['total']} | "
            f"{stats['migration_exception_count']} |"
        )
    lines.extend([
        "",
        "## Phase 8",
        "",
    ])
    for operation in result["phase8"]["operations"]:
        lines.append(f"- `{operation['operation']}`: byte-identical, SHA-256 `{operation['sha256']}`")
    lines.extend([
        "",
        "## Remaining boundary",
        "",
        "Issue #161 must still prove all 14 `goc_*` squads spawn in the native Gates of Hell engine.",
        "",
    ])
    return "\n".join(lines)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--payload", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()

    payload = load_payload(args.payload)
    result = {
        "schema": "gates-of-codex.independent-actor-economy-audit",
        "schema_version": 1,
        "audited_commit": AUDITED_COMMIT,
        "accepted_payload_sha256": ACCEPTED_PAYLOAD_SHA256,
        "wiring_signature": ACCEPTED_WIRING_SIGNATURE,
        "phase5": run_phase5(payload),
        "phase6": run_phase6(payload),
        "phase7": run_phase7(payload),
        "phase8": run_phase8(payload),
        "verdict": "approve",
        "remaining_gate": "issue #161 native Gates of Hell wrapper spawn acceptance",
    }

    args.output_dir.mkdir(parents=True, exist_ok=True)
    json_path = args.output_dir / "phase5-8.json"
    md_path = args.output_dir / "phase5-8.md"
    json_path.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    md_path.write_text(markdown_report(result), encoding="utf-8")
    print(json.dumps({
        "ok": True,
        "verdict": result["verdict"],
        "json": str(json_path),
        "markdown": str(md_path),
        "json_sha256": sha256_bytes(json_path.read_bytes()),
        "markdown_sha256": sha256_bytes(md_path.read_bytes()),
    }, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
